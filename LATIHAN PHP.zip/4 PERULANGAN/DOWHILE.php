<?php

$urutan = 1 ;

DO
{
	echo "jadwal makan ke : "  .  $urutan ;
	echo " <br> ";

	$urutan++ ;
}  
WHILE ( $urutan  <=  3 ) 




?>