<?php

$urutan = 1 ;

WHILE ( $urutan  <=  3 ) 
{
echo "jadwal makan ke : "  .  $urutan ;
echo " <br> ";

$urutan++ ;
} 


?>