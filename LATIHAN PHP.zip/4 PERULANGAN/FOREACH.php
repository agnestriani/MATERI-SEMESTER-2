<?php


$buah_buahan = array ( "Jeruk", "Apel", "Pisang" );


FOREACH ( $buah_buahan as $nama_buah )
{
	echo $nama_buah;
	echo "<br>";
} 


?> 