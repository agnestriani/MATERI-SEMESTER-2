<?php


for  ($urutan = 1 ; $urutan <3 ; $urutan ++ )  
{
	echo " jadwal makan ke : ". $urutan ;
	echo " <br> " ;	
	
}
	
	
?>