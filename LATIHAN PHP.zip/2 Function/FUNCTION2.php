<?php


function hitung_luas ( $panjang , $lebar )
{	
	
	return $panjang * $lebar  ;
}


echo " Luasnya adalah : " . hitung_luas  (4,3) ;

?>