<?php

function hitung_luas( $panjang , $lebar )
{	
	$luas =  $panjang * $lebar ;
	echo "luasnya adalah : $luas"."<br>";	
}

hitung_luas(5,3);

?>