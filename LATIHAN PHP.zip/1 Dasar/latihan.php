<?php

$luas  ;
$panjang = 10  ;
$lebar = 7  ;

$luas = $panjang * $lebar   ;

echo "Luasnya adalah : " . $luas .   "  meter"  ;

?>
