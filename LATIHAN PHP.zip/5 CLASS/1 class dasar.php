<?php

	class mobil
	{
		//property
		
		//method 
	}
	
	
	$mobil_balap =  new  mobil ;		
	
		
?>